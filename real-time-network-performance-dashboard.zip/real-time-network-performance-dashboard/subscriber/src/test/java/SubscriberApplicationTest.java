public class SubscriberApplicationTest {
}
