package com.example.simulator;

import com.example.metrics.Metric;
import com.example.metrics.MetricProducer;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Random;

@Component
public class SimulatorRunner {

    private final MetricProducer producer;
    private final Random random = new Random();

    public SimulatorRunner(MetricProducer producer) {
        this.producer = producer;
    }

    @Scheduled(fixedRate = 3000) // runs every 3 seconds
    public void generateMetric() {
        Metric metric = new Metric();
        metric.setNodeId(random.nextInt(5) + 1); // node 1-5
        metric.setNetworkId(1);
        metric.setLatency(10 + random.nextDouble() * 100);
        metric.setThroughput(50 + random.nextDouble() * 500);
        metric.setErrorRate(random.nextDouble() * 5);
        metric.setTimestamp(LocalDateTime.now());

        producer.sendMetric(metric);
        // console
        System.out.println("Generated Metric: " + metric);
    }
}
