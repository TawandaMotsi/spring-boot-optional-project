package com.example.metrics;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class MetricProducer {

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${topic.name}")
    private String topic;

    public MetricProducer(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMetric(Metric metric) {
        try {
            String json = objectMapper.writeValueAsString(metric);
            kafkaTemplate.send(topic, json);
            System.out.println("Sent: " + json);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
